package tests;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import calculator.model.Calculator;

public class TestCalculator {

    @Test
    public void testCalculator() {
        Calculator calculator = new Calculator();

        assertEquals(0.0, calculator.displayNumber(), 0.001);

        calculator.numberPressed(4);
        calculator.numberPressed(6);
        calculator.numberPressed(1);
        assertEquals(461.0, calculator.displayNumber(), 0.001);

        calculator.clearPressed();
        calculator.numberPressed(2);
        calculator.numberPressed(5);
        calculator.addPressed();
        calculator.numberPressed(5);
        calculator.equalsPressed();
        assertEquals(30.0, calculator.displayNumber(), 0.001);

        calculator.clearPressed();
        assertEquals(0.0, calculator.displayNumber(), 0.001);

        calculator.numberPressed(1);
        calculator.numberPressed(2);
        calculator.decimalPressed();
        calculator.decimalPressed();
        calculator.numberPressed(5);
        assertEquals(12.5, calculator.displayNumber(), 0.001);

        calculator.clearPressed();
        calculator.numberPressed(8);
        calculator.numberPressed(0);
        calculator.subtractPressed();
        calculator.numberPressed(1);
        calculator.numberPressed(0);
        calculator.equalsPressed();
        calculator.equalsPressed();
        assertEquals(60.0, calculator.displayNumber(), 0.001);
    }
}