package calculator.model;

public class EnteringSecondDecimal implements State {
    private final Calculator calculator;
    private double factor = 0.1;

    public EnteringSecondDecimal(Calculator calculator) {
        this.calculator = calculator;
    }

    @Override
    public void numberPressed(int number) {
        this.calculator.rightOperand = this.calculator.rightOperand + (number * this.factor);
        this.factor = this.factor / 10.0;
    }

    @Override
    public void decimalPressed() {
    }

    @Override
    public double displayNumber() {
        return this.calculator.rightOperand;
    }

    @Override
    public void clearPressed() {
        this.calculator.setState(new InitialState(this.calculator));
    }

    @Override
    public void equalsPressed() {
        double result = this.calculator.currentOperation.compute(this.calculator.leftOperand, this.calculator.rightOperand);
        this.calculator.leftOperand = result;
        this.calculator.setState(new ResultState(this.calculator));
    }

    @Override public void addPressed() {}
    @Override public void subtractPressed() {}
    @Override public void multiplyPressed() {}
    @Override public void dividePressed() {}
}