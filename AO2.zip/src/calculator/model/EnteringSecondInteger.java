package calculator.model;

public class EnteringSecondInteger implements State {
    private final Calculator calculator;

    public EnteringSecondInteger(Calculator calculator) {
        this.calculator = calculator;
    }

    @Override
    public void numberPressed(int number) {
        this.calculator.rightOperand = this.calculator.rightOperand * 10 + number;
    }

    @Override
    public void decimalPressed() {
        EnteringSecondDecimal nextState = new EnteringSecondDecimal(this.calculator);
        this.calculator.setState(nextState);
    }

    @Override
    public double displayNumber() {
        return this.calculator.rightOperand;
    }

    @Override
    public void clearPressed() {
        this.calculator.setState(new InitialState(this.calculator));
    }

    @Override
    public void equalsPressed() {
        double result = this.calculator.currentOperation.compute(
                this.calculator.leftOperand,
                this.calculator.rightOperand
        );
        this.calculator.leftOperand = result;
        this.calculator.setState(new ResultState(this.calculator));
    }

    @Override public void addPressed() {}
    @Override public void subtractPressed() {}
    @Override public void multiplyPressed() {}
    @Override public void dividePressed() {}
}