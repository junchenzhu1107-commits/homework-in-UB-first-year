package calculator.model;

public interface State {
    void numberPressed(int number);
    void decimalPressed();
    void addPressed();
    void subtractPressed();
    void multiplyPressed();
    void dividePressed();
    void equalsPressed();
    void clearPressed();
    double displayNumber();
}