package calculator.model;

public class ResultState implements State {
    private final Calculator calculator;

    public ResultState(Calculator calculator) {
        this.calculator = calculator;
    }

    @Override
    public double displayNumber() {
        return this.calculator.leftOperand;
    }

    @Override
    public void equalsPressed() {
        double result = this.calculator.currentOperation.compute(
                this.calculator.leftOperand,
                this.calculator.rightOperand
        );
        this.calculator.leftOperand = result;
    }

    @Override
    public void numberPressed(int number) {
        EnteringFirstInteger nextState = new EnteringFirstInteger(this.calculator);
        this.calculator.leftOperand = 0.0;
        nextState.numberPressed(number);
        this.calculator.setState(nextState);
    }

    @Override
    public void addPressed() {
        this.calculator.currentOperation = new Addition();
        this.calculator.setState(new OperatorPressed(this.calculator));
    }

    @Override
    public void subtractPressed() {
        this.calculator.currentOperation = new Subtraction();
        this.calculator.setState(new OperatorPressed(this.calculator));
    }

    @Override
    public void multiplyPressed() {
        this.calculator.currentOperation = new Multiplication();
        this.calculator.setState(new OperatorPressed(this.calculator));
    }

    @Override
    public void dividePressed() {
        this.calculator.currentOperation = new Division();
        this.calculator.setState(new OperatorPressed(this.calculator));
    }

    @Override
    public void clearPressed() {
        this.calculator.setState(new InitialState(this.calculator));
    }

    @Override public void decimalPressed() {}
}