package calculator.model;

public class OperatorPressed implements State {
    private final Calculator calculator;

    public OperatorPressed(Calculator calculator) {
        this.calculator = calculator;
        this.calculator.rightOperand = 0.0;
    }

    @Override
    public void numberPressed(int number) {
        EnteringSecondInteger nextState = new EnteringSecondInteger(this.calculator);
        nextState.numberPressed(number);
        this.calculator.setState(nextState);
    }

    @Override
    public void decimalPressed() {
        EnteringSecondDecimal nextState = new EnteringSecondDecimal(this.calculator);
        this.calculator.setState(nextState);
    }

    @Override
    public double displayNumber() {
        return this.calculator.leftOperand;
    }

    @Override
    public void clearPressed() {
        this.calculator.setState(new InitialState(this.calculator));
    }

    @Override
    public void addPressed() {
        this.calculator.currentOperation = new Addition();
    }

    @Override
    public void subtractPressed() {
        this.calculator.currentOperation = new Subtraction();
    }

    @Override
    public void multiplyPressed() {
        this.calculator.currentOperation = new Multiplication();
    }

    @Override
    public void dividePressed() {
        this.calculator.currentOperation = new Division();
    }

    @Override public void equalsPressed() {}
}