package calculator.model;

public class InitialState implements State {
    private final Calculator calculator;

    public InitialState(Calculator calculator) {
        this.calculator = calculator;
        this.calculator.leftOperand = 0.0;
        this.calculator.rightOperand = 0.0;
    }

    @Override
    public void numberPressed(int number) {
        EnteringFirstInteger nextState = new EnteringFirstInteger(this.calculator);
        nextState.numberPressed(number);
        this.calculator.setState(nextState);
    }

    @Override
    public void decimalPressed() {
        EnteringFirstDecimal nextState = new EnteringFirstDecimal(this.calculator);
        this.calculator.setState(nextState);
    }

    @Override
    public double displayNumber() {
        return 0.0;
    }

    @Override
    public void clearPressed() {}

    @Override public void addPressed() {}
    @Override public void subtractPressed() {}
    @Override public void multiplyPressed() {}
    @Override public void dividePressed() {}
    @Override public void equalsPressed() {}
}