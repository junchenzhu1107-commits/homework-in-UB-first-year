package calculator.model;

public class Subtraction implements Operation{
    @Override
    public double compute(double left, double right) { return left - right; }
}
