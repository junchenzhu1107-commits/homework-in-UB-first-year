package calculator.model;

public class Division implements Operation{
    @Override
    public double compute(double left, double right) { return left / right; }
}
