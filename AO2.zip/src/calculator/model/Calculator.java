package calculator.model;

public class Calculator {
    private State state;

    public double leftOperand = 0.0;
    public double rightOperand = 0.0;
    public Operation currentOperation;

    public Calculator() {
        this.state = new InitialState(this);
    }

    public void setState(State state) {
        this.state = state;
    }

    public double displayNumber() {
        return this.state.displayNumber();
    }

    public void clearPressed() {
        this.state.clearPressed();
    }

    public void numberPressed(int number) {
        this.state.numberPressed(number);
    }

    public void dividePressed() {
        this.state.dividePressed();
    }

    public void multiplyPressed() {
        this.state.multiplyPressed();
    }

    public void subtractPressed() {
        this.state.subtractPressed();
    }

    public void addPressed() {
        this.state.addPressed();
    }

    public void equalsPressed() {
        this.state.equalsPressed();
    }

    public void decimalPressed() {
        this.state.decimalPressed();
    }
}