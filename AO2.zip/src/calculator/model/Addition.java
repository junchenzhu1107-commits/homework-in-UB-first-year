package calculator.model;

public class Addition implements Operation{
    @Override
    public double compute(double left, double right) { return left + right; }
}
