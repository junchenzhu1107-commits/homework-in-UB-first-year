package calculator.model;

public interface Operation {
    double compute(double left, double right);
}