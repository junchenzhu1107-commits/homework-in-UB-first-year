package calculator.model;

public class Multiplication implements Operation{
    @Override
    public double compute(double left, double right) { return left * right; }
}
