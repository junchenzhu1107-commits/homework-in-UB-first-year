package calculator.model;

public class EnteringFirstInteger implements State {
    private final Calculator calculator;

    public EnteringFirstInteger(Calculator calculator) {
        this.calculator = calculator;
    }

    @Override
    public void numberPressed(int number) {
        this.calculator.leftOperand = this.calculator.leftOperand * 10 + number;
    }

    @Override
    public void decimalPressed() {
        // 切换至输入小数状态
        EnteringFirstDecimal nextState = new EnteringFirstDecimal(this.calculator);
        this.calculator.setState(nextState);
    }

    @Override
    public double displayNumber() {
        return this.calculator.leftOperand;
    }

    @Override
    public void clearPressed() {
        this.calculator.setState(new InitialState(this.calculator));
    }

    @Override
    public void addPressed() {
        this.calculator.currentOperation = new Addition();
        this.calculator.setState(new OperatorPressed(this.calculator));
    }

    @Override
    public void subtractPressed() {
        this.calculator.currentOperation = new Subtraction();
        this.calculator.setState(new OperatorPressed(this.calculator));
    }

    @Override
    public void multiplyPressed() {
        this.calculator.currentOperation = new Multiplication();
        this.calculator.setState(new OperatorPressed(this.calculator));
    }

    @Override
    public void dividePressed() {
        this.calculator.currentOperation = new Division();
        this.calculator.setState(new OperatorPressed(this.calculator));
    }

    @Override public void equalsPressed() {}
}