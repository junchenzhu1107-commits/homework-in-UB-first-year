package calculator.model;

public class EnteringFirstDecimal implements State {
    private final Calculator calculator;
    private double factor = 0.1;

    public EnteringFirstDecimal(Calculator calculator) {
        this.calculator = calculator;
    }

    @Override
    public void numberPressed(int number) {
        this.calculator.leftOperand = this.calculator.leftOperand + (number * this.factor);
        this.factor = this.factor / 10.0;
    }

    @Override
    public void decimalPressed() {}

    @Override
    public double displayNumber() {
        return this.calculator.leftOperand;
    }

    @Override
    public void clearPressed() {
        this.calculator.setState(new InitialState(this.calculator));
    }

    @Override
    public void addPressed() {
        this.calculator.currentOperation = new Addition();
        this.calculator.setState(new OperatorPressed(this.calculator));
    }

    @Override
    public void subtractPressed() {
        this.calculator.currentOperation = new Subtraction();
        this.calculator.setState(new OperatorPressed(this.calculator));
    }

    @Override
    public void multiplyPressed() {
        this.calculator.currentOperation = new Multiplication();
        this.calculator.setState(new OperatorPressed(this.calculator));
    }

    @Override
    public void dividePressed() {
        this.calculator.currentOperation = new Division();
        this.calculator.setState(new OperatorPressed(this.calculator));
    }

    @Override public void equalsPressed() {}
}