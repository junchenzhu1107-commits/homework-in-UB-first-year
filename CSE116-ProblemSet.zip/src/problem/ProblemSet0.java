package problem;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;

public class ProblemSet0 {
    public static int sumOfDigits( int number) {
        int total=0;
        int newNumber= Math.abs(number);
        while (newNumber >0){
            total+=newNumber%10;
            newNumber=newNumber/10;
        }
        return total;
    }

    public static double average(ArrayList<Double> numbers) {
        if (numbers.isEmpty()){
            return 0.0;
        }
        double averageNum=0.0;
        double count=0.0;
        for (int i=0; i<numbers.size(); i++){
            count+=1.0;
            averageNum+=numbers.get(i);
        }
        return averageNum/count;
    }

    public static int longestStringIndex(ArrayList<String> list) {
        if (list.isEmpty()){
            return -1;
        }
        int maxIndex=0;
        int maxLength=0;
        for (int i=0; i< list.size(); i++){
            if (list.get(i).length()>maxLength){
                maxLength=list.get(i).length();
                maxIndex=i;
            }
        }
        return maxIndex;
    }

    public static int countElements(HashMap<String,ArrayList<Integer>> dict){
        int count=0;
        for (ArrayList<Integer> value : dict.values()){
            for (int x=0; x<value.size() ;x++){
                count+=1;
            }
        }
        return count;
    }

    public static String bestKey(HashMap<String, Integer> haXi){
        if (haXi.isEmpty()){
            return "";
        }
        String x=null;
        for (String key : haXi.keySet()){
            if (x==null || haXi.get(key)>haXi.get(x)){
                x=key;
            }
        }
        return x;
    }

    public static int wordCount(String filename){
        int total=0;
        try{
            List<String> allLines= Files.readAllLines(Paths.get(filename));
            for (String line :allLines) {
                String[] parts = line.split(",");
                total += parts.length;
            }
        }catch(Exception e) {
            total= 0;
        }
        return total;
    }

    public static ArrayList<Integer> sumOfLines(String filename){
        ArrayList<Integer> result =new ArrayList<>();
        try{
            List<String> allLines= Files.readAllLines(Paths.get(filename));
            for (String line : allLines){
                String[] parts=line.split(",");
                int rowSum=0;
                for (String p: parts){
                    rowSum+=Integer.parseInt(p);
                }
                result.add(rowSum);
            }
            return result;
        }catch(Exception e){
            return result;
        }
    }

    public static ArrayList<Integer> factors(int input){
        ArrayList<Integer> arr1= new ArrayList<>();
        for (int x=1;x<=input; x++){
            if (input% x==0){
                arr1.add(x);
            }
        }
        return arr1;
    }

    public static boolean isPrime(int num){
        ArrayList<Integer> arr2= factors(num);
        return arr2.size()==2;
    }

    public static ArrayList<Integer> primeFactorization(int num){
        ArrayList<Integer> result= new ArrayList<>();
        for (int x=2; x<=num; x++){
            while (num% x==0) {
                result.add(x);
                num = num / x;
            }
        }
        return result;
    }
    // Create remaining methods in this class

}
