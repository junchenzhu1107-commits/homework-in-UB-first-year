package app.gameengine.model.datastructures;

import app.gameengine.statistics.GameStat;

/**
 * Compares two GameStat objects based on their scores.
 * Returns true if the first score is strictly greater than the second.
 */
public class ScoreComparator implements Comparator<GameStat> {

    @Override
    public boolean compare(GameStat a, GameStat b) {
        if (a.getScore() > b.getScore()) {
            return true;
        }
        return false;
    }
}