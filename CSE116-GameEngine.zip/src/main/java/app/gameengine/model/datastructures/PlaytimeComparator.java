package app.gameengine.model.datastructures;

import app.gameengine.statistics.GameStat;

/**
 * Compares two GameStat objects based on their playtimes.
 * Returns true if the first playtime is strictly less than the second.
 */
public class PlaytimeComparator implements Comparator<GameStat> {

    @Override
    public boolean compare(GameStat a, GameStat b) {
        if (a.getPlaytime() < b.getPlaytime()) {
            return true;
        }
        return false;
    }
}