package app.gameengine.model.datastructures;

import app.gameengine.statistics.GameStat;

/**
 * Compares two GameStat objects based on their entry names lexicographically.
 */
public class LevelNameComparator implements Comparator<GameStat> {

    @Override
    public boolean compare(GameStat a, GameStat b) {
        // String.compareTo returns < 0 if the string is lexicographically less
        if (a.getEntryName().compareTo(b.getEntryName()) < 0) {
            return true;
        }
        return false;
    }
}