package app.gameengine.model.ai.roguelike;

import app.gameengine.Level;
import app.gameengine.model.ai.Decision;
import app.gameengine.model.gameobjects.Agent;
import app.gameengine.model.physics.Vector2D;
import app.gameengine.utils.Timer;
import app.games.topdownobjects.EnemyHomingProjectile;

public class ShootHomingProjectile extends Decision {
    private Timer timer;

    public ShootHomingProjectile(Agent agent, String name, double cooldown) {
        super(agent, name);
        this.timer = new Timer(cooldown);
    }

    @Override
    public boolean decide(double dt, Level level) {
        return false;
    }

    @Override
    public void doAction(double dt, Level level) {
        this.getAgent().setVelocity(0, 0);

        int overflows = this.timer.tick(dt);

        if (overflows > 0) {
            Vector2D playerLoc = level.getPlayer().getLocation();
            Vector2D agentLoc = this.getAgent().getLocation();

            Vector2D direction = Vector2D.sub(playerLoc, agentLoc);
            direction.normalize();

            this.getAgent().setOrientation(direction.getX(), direction.getY());

            EnemyHomingProjectile homing = new EnemyHomingProjectile(agentLoc.getX(), agentLoc.getY());

            this.getAgent().fireProjectile(homing, 10.0, level);
        }
    }
}