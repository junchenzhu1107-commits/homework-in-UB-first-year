package app.gameengine.model.ai.pacman;

import app.gameengine.Level;
import app.gameengine.model.ai.Decision;
import app.gameengine.model.physics.Vector2D;
import app.gameengine.utils.PacmanUtils;
import app.games.pacman.Ghost;
import app.games.pacman.PacmanGame;
import java.util.ArrayList;

public class Scatter extends Decision {
    private Ghost ghost;
    private PacmanGame game;
    private Vector2D lastLocation = null;

    public Scatter(Ghost ghost, PacmanGame game, String name) {
        super(ghost, name);
        this.ghost = ghost;
        this.game = game;
    }

    @Override
    public boolean decide(double dt, Level level) {
        return false; // 规范要求：总是返回 false
    }

    @Override
    public void doAction(double dt, Level level) {
        if (PacmanUtils.canAct(ghost, dt, lastLocation)) {
            Vector2D target = PacmanUtils.getScatterTarget(game.getCurrentLevel(), ghost);
            ArrayList<Vector2D> validDirs = PacmanUtils.getValidDirs(game.getCurrentLevel(), ghost);
            Vector2D bestDir = PacmanUtils.getBestDirection(validDirs, ghost.getLocation(), target);

            if (bestDir != null) {
                ghost.setOrientation(bestDir.getX(), bestDir.getY());
            }
            lastLocation = Vector2D.round(ghost.getLocation());
        }
        ghost.followPath(dt);
    }
}