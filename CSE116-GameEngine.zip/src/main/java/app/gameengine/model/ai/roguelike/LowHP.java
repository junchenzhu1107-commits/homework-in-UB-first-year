package app.gameengine.model.ai.roguelike;

import app.gameengine.Level;
import app.gameengine.model.ai.Decision;
import app.gameengine.model.gameobjects.Agent;

public class LowHP extends Decision {
    private int threshold;

    public LowHP(Agent agent, String name, int threshold) {
        super(agent, name);
        this.threshold = threshold;
    }

    @Override
    public boolean decide(double dt, Level level) {
        return this.getAgent().getHP() <= this.threshold;
    }

    @Override
    public void doAction(double dt, Level level) {}
}