package app.gameengine.model.ai.pacman;

import app.gameengine.Level;
import app.gameengine.model.ai.Decision;
import app.gameengine.model.physics.Vector2D;
import app.games.pacman.Ghost;

public class Idle extends Decision {
    private Ghost ghost;

    public Idle(Ghost ghost, String name) {
        super(ghost, name);
        this.ghost = ghost;
    }

    @Override
    public boolean decide(double dt, Level level) { return false; }

    @Override
    public void doAction(double dt, Level level) {
        if (ghost.getVelocity().magnitude() > 0) {
            return;
        }
        Vector2D currentOri = ghost.getOrientation();
        ghost.setOrientation(-currentOri.getX(), -currentOri.getY());

        ghost.followPath(dt);
    }
}