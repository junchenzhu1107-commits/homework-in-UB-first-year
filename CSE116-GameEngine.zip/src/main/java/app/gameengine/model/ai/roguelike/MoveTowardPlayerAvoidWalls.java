package app.gameengine.model.ai.roguelike;

import app.gameengine.Level;
import app.gameengine.model.ai.Decision;
import app.gameengine.model.gameobjects.Agent;
import app.gameengine.utils.PathfindingUtils;

public class MoveTowardPlayerAvoidWalls extends Decision {
    public MoveTowardPlayerAvoidWalls(Agent agent, String name) {
        super(agent, name);
    }

    @Override
    public boolean decide(double dt, Level level){
        return level.getPlayer() != null;
    }

    @Override
    public void doAction(double dt, Level level) {
        this.getAgent().setPath(PathfindingUtils.findPathAvoidWalls(
                level,
                this.getAgent().getLocation(),
                level.getPlayer().getLocation()
        ));

        if (this.getAgent().getPath() != null) {
            this.getAgent().followPath(dt);
        } else {
            this.getAgent().setVelocity(0, 0);
        }
    }
}