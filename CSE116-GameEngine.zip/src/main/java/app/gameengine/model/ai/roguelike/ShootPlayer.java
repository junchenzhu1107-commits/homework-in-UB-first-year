package app.gameengine.model.ai.roguelike;

import app.gameengine.Level;
import app.gameengine.model.ai.Decision;
import app.gameengine.model.gameobjects.Agent;
import app.games.topdownobjects.EnemyArrowProjectile;
import app.gameengine.model.physics.Vector2D;
import app.gameengine.utils.Timer;

public class ShootPlayer extends Decision {
    private Timer timer;

    public ShootPlayer(Agent agent, String name, double cooldown) {
        super(agent, name);
        this.timer = new Timer(cooldown);
    }

    @Override
    public boolean decide(double dt, Level level) {
        return false;
    }

    @Override
    public void doAction(double dt, Level level) {
        this.getAgent().setVelocity(0, 0);
        int overflows = this.timer.tick(dt);

        if (overflows > 0) {
            Vector2D playerLoc = level.getPlayer().getLocation();
            Vector2D agentLoc = this.getAgent().getLocation();

            Vector2D direction = Vector2D.sub(playerLoc, agentLoc);

            direction.normalize();

            this.getAgent().setOrientation(direction.getX(), direction.getY());

            EnemyArrowProjectile arrow = new EnemyArrowProjectile(agentLoc.getX(), agentLoc.getY());
            this.getAgent().fireProjectile(arrow, 10.0, level);
        }
    }
}