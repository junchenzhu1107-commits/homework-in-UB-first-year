package app.gameengine.model.ai.roguelike;

import app.gameengine.Level;
import app.gameengine.model.ai.Decision;
import app.gameengine.model.gameobjects.Agent;
import app.gameengine.model.physics.Vector2D;

public class NearPlayer extends Decision {
    private double limit;

    public NearPlayer(Agent agent, String name, double limit) {
        super(agent, name);
        this.limit = limit;
    }

    @Override
    public boolean decide(double dt, Level level) {
        Vector2D agentLoc = this.getAgent().getLocation();
        Vector2D playerLoc = level.getPlayer().getLocation();

        return Vector2D.euclideanDistance(agentLoc, playerLoc) <= this.limit;
    }

    @Override
    public void doAction(double dt, Level level) {}
}