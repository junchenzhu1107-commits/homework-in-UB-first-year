package app.gameengine.model.ai;

import app.gameengine.Level;
import app.gameengine.model.datastructures.BinaryTreeNode;

public class DecisionTree {
    private BinaryTreeNode<Decision> tree;

    public DecisionTree(BinaryTreeNode<Decision> tree) {
        this.tree = tree;
    }

    public BinaryTreeNode<Decision> getTree() { return tree; }

    public void setTree(BinaryTreeNode<Decision> tree) { this.tree = tree; }

    public Decision traverse(BinaryTreeNode<Decision> node, double dt, Level level) {
        if (node == null) return null;

        if (node.getLeft() == null && node.getRight() == null) {
            return node.getValue();
        }

        boolean result = node.getValue().decide(dt, level);

        BinaryTreeNode<Decision> nextNode = result ? node.getRight() : node.getLeft();

        if (nextNode == null) {
            return null;
        }

        // 4. 继续递归
        return traverse(nextNode, dt, level);
    }

    public void traverse(double dt, Level level) {
        Decision actionNode = traverse(this.tree, dt, level);
        if (actionNode != null) {
            actionNode.doAction(dt, level);
        }
    }
}