package app.gameengine.model.gameobjects;

import app.gameengine.Game;
import app.gameengine.Level;

public abstract class Collectible extends StaticGameObject {
    // 规范要求：存储 itemID 和 game
    private String itemID;
    private Game game;

    public Collectible(double x, double y, Game game, String itemID) {
        super(x, y); // 2个给 super
        this.game = game;
        this.itemID = itemID;
    }

    public String getItemID() {
        return this.itemID;
    }

    public abstract void use(Level level);

    @Override
    public void collideWithDynamicObject(DynamicGameObject otherObject) {
        if (otherObject.isPlayer()) {
            // 通过存储的 game 获取 Player 并调用 addInventoryItem
            Player player = this.game.getPlayer();
            player.addInventoryItem(this);
            // 销毁物品
            this.destroy();
        }
    }

    @Override
    public boolean isSolid() {
        return false;
    }
}