package app.gameengine.model.physics;

import java.util.ArrayList;

import app.Settings;
import app.gameengine.Level;
import app.gameengine.model.gameobjects.DynamicGameObject;
import app.gameengine.model.gameobjects.StaticGameObject;

/**
 * Physics engine for handling collision detection and resolution within a game.
 * <p>
 * This class is meant to be the used when updating objects to apply physics and
 * object interactions. Whenever objects collide, that should be observed and
 * handled from here.
 * 
 * @see Collidable
 * @see DynamicGameObject
 * @see StaticGameObject
 * @see Level
 */
public class PhysicsEngine {

    /**
     * Update the physics for an entire level. This means updating each dynamic
     * object according to its velocity, and handling all collisions within the
     * level.
     * 
     * @param dt    the time elapsed since the last update, in seconds
     * @param level the level being updated
     */
    public void updateLevel(double dt, Level level) {
        for (DynamicGameObject gameObject : level.getDynamicObjects()) {
            updateObject(dt, gameObject);
        }
        processAllCollisions(level);
    }

    /**
     * Update a single dynamic object according to its velocity.
     * 
     * @param dt     the time elapsed since the last update, in seconds
     * @param object the object being updated
     */
    public void updateObject(double dt, DynamicGameObject object) {
        Vector2D currentLoc = object.getLocation();
        Vector2D vel = object.getVelocity();
        double newX = currentLoc.getX() + vel.getX() * dt;
        double newY = currentLoc.getY() + vel.getY() * dt;
        object.setLocation(newX, newY);
    }

    /**
     * Detect whether a collision between two hitboxes has occurred. A collision is
     * defined as the two hitboxes having an overlapping distance of strictly
     * greater than 0.
     * 
     * @param hitbox1 the first hitbox
     * @param hitbox2 the second hitbox
     * @return {@code true} if a collision is occurring, {@code false} otherwise
     */
    public boolean detectCollision(Hitbox hitbox1, Hitbox hitbox2) {
        Vector2D pos1 = hitbox1.getLocation();
        Vector2D dim1 = hitbox1.getDimensions();

        Vector2D pos2 = hitbox2.getLocation();
        Vector2D dim2 = hitbox2.getDimensions();

        if (pos1.getX()>= pos2.getX() + dim2.getX() || //right
            pos1.getX() + dim1.getX() <= pos2.getX() || //left
            pos1.getY() >= pos2.getY() + dim2.getY() || //down
            pos1.getY() + dim1.getY() <= pos2.getY()){ //up
            return false;
        }
        return true;
    }

    /**
     * Returns the minimum overlapping distance of two hitboxes. If the hitboxes are
     * colliding, this distance should be greater than 0. Otherwise, they are not
     * colliding.
     * <p>
     * This method assumes that the hitboxes are already colliding, and the results
     * are undefined otherwise.
     * 
     * @param hitbox1 the first hitbox
     * @param hitbox2 the second hitbox
     * @return the minimum overlapping distance
     */
    public double getOverlap(Hitbox hitbox1, Hitbox hitbox2) {
        double x1 = hitbox1.getLocation().getX();
        double y1 = hitbox1.getLocation().getY();
        double w1 = hitbox1.getDimensions().getX();
        double h1 = hitbox1.getDimensions().getY();

        double x2 = hitbox2.getLocation().getX();
        double y2 = hitbox2.getLocation().getY();
        double w2 = hitbox2.getDimensions().getX();
        double h2 = hitbox2.getDimensions().getY();

        double overlapLeft = x2 + w2 - x1;
        double overlapRight = x1 + w1 - x2;
        double overlapTop = y2 + h2 - y1;
        double overlapBottom = y1 + h1 - y2;

        double minOverlap = overlapLeft;
        if (overlapRight < minOverlap){ minOverlap = overlapRight;}
        if (overlapTop < minOverlap){ minOverlap = overlapTop;}
        if (overlapBottom < minOverlap){ minOverlap = overlapBottom;}

        return minOverlap;
    }

    /**
     * Process all collisions within a level. This means that for each dynamic
     * object, detect which other dynamic or static objects it is colliding with,
     * and defer collision behavior to the respective objects.
     * 
     * @param level the level being updated
     */
    public void processAllCollisions(Level level) {
        ArrayList<DynamicGameObject> dynamicObjects = level.getDynamicObjects();
        ArrayList<StaticGameObject> staticObjects = level.getStaticObjects();

        for (int i = 0; i < dynamicObjects.size(); i++) {
            DynamicGameObject object1 = dynamicObjects.get(i);
            if (Settings.noclip() && object1.isPlayer()) {
                continue;
            }
            for (int j = i + 1; j < dynamicObjects.size(); j++) {
                DynamicGameObject object2 = dynamicObjects.get(j);
                if (Settings.noclip() && object2.isPlayer()) {
                    continue;
                }
                if (detectCollision(object1.getHitbox(), object2.getHitbox())) {
                    object1.collideWithDynamicObject(object2);
                    object2.collideWithDynamicObject(object1);
                }
            }
            for (int j = 0; j < staticObjects.size(); j++) {
                StaticGameObject staticObject = staticObjects.get(j);
                if (detectCollision(object1.getHitbox(), staticObject.getHitbox())) {
                    staticObject.collideWithDynamicObject(object1);
                    object1.collideWithStaticObject(staticObject);
                }
            }
        }
    }
}
