package app.gameengine.utils;

import app.gameengine.Level;
import app.gameengine.model.datastructures.LinkedListNode;
import app.gameengine.model.gameobjects.GameObject;
import app.gameengine.model.physics.Vector2D;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class PathfindingUtils {
    public static LinkedListNode<Vector2D> findPath(Vector2D start, Vector2D end) {
        Vector2D startTile = Vector2D.floor(start);
        Vector2D endTile = Vector2D.floor(end);

        double curX = startTile.getX();
        double curY = startTile.getY();
        double targetX = endTile.getX();
        double targetY = endTile.getY();

        LinkedListNode<Vector2D> head = new LinkedListNode<>(new Vector2D(curX, curY), null);
        LinkedListNode<Vector2D> current = head;

        while (curX != targetX) {
            curX += (targetX > curX) ? 1.0 : -1.0;
            LinkedListNode<Vector2D> nextNode = new LinkedListNode<>(new Vector2D(curX, curY), null);
            current.setNext(nextNode);
            current = nextNode;
        }

        while (curY != targetY) {
            curY += (targetY > curY) ? 1.0 : -1.0;
            LinkedListNode<Vector2D> nextNode = new LinkedListNode<>(new Vector2D(curX, curY), null);
            current.setNext(nextNode);
            current = nextNode;
        }

        return head;
    }

    public static LinkedListNode<Vector2D> findPathAvoidWalls(Level level, Vector2D start, Vector2D end) {

        Vector2D startTile = Vector2D.floor(start);
        Vector2D endTile = Vector2D.floor(end);

        if (!GameUtils.isInBounds(level, startTile) || !GameUtils.isInBounds(level, endTile)) return null;
        if (isTileSolid(startTile, level) || isTileSolid(endTile, level)) return null;
        if (startTile.equals(endTile)) return new LinkedListNode<>(startTile, null);

        LinkedList<LinkedListNode<Vector2D>> queue = new LinkedList<>();
        ArrayList<Vector2D> visited = new ArrayList<>();

        queue.add(new LinkedListNode<>(startTile, null));
        visited.add(startTile);

        LinkedListNode<Vector2D> endNode = null;

        while (!queue.isEmpty()) {
            LinkedListNode<Vector2D> current = queue.remove(0);

            if (current.getValue().equals(endTile)) {
                endNode = current;
                break;
            }

            checkAndAddNode(current, 1, 0, level, queue, visited); //right
            checkAndAddNode(current, -1, 0, level, queue, visited); //left
            checkAndAddNode(current, 0, 1, level, queue, visited); //down
            checkAndAddNode(current, 0, -1, level, queue, visited); //up
        }

        if (endNode == null) return null;

        LinkedListNode<Vector2D> resultHead = null;
        LinkedListNode<Vector2D> temp = endNode;
        while (temp != null) {
            resultHead = new LinkedListNode<>(temp.getValue(), resultHead);
            temp = temp.getNext();
        }

        return resultHead;
    }

    private static void checkAndAddNode(LinkedListNode<Vector2D> current, double dx, double dy,
                                        Level level, LinkedList<LinkedListNode<Vector2D>> queue,
                                        ArrayList<Vector2D> visited) {
        Vector2D currentLoc = current.getValue();
        Vector2D nextLoc = new Vector2D(currentLoc.getX() + dx, currentLoc.getY() + dy);

        if (GameUtils.isInBounds(level, nextLoc) && !isTileSolid(nextLoc, level)) {
            boolean alreadyVisited = false;
            for (int i = 0; i < visited.size(); i++) {
                Vector2D v = visited.get(i);
                if (v.getX() == nextLoc.getX() && v.getY() == nextLoc.getY()) {
                    alreadyVisited = true;
                    break;
                }
            }

            if (!alreadyVisited) {
                visited.add(nextLoc);
                queue.add(new LinkedListNode<>(nextLoc, current));
            }
        }
    }

    private static boolean isTileSolid(Vector2D tile, Level level) {
        java.util.ArrayList<app.gameengine.model.gameobjects.StaticGameObject> statics = level.getStaticObjects();
        for (int i = 0; i < statics.size(); i++) {
            GameObject obj = statics.get(i);
            if (obj.isSolid() && Vector2D.floor(obj.getLocation()).equals(tile)) {
                return true;
            }
        }

        java.util.ArrayList<app.gameengine.model.gameobjects.DynamicGameObject> dynamics = level.getDynamicObjects();
        for (int i = 0; i < dynamics.size(); i++) {
            GameObject obj = dynamics.get(i);
            if (obj.isSolid() && Vector2D.floor(obj.getLocation()).equals(tile)) {
                return true;
            }
        }

        return false;
    }
}