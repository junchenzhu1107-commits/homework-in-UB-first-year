package app.gameengine;

import app.gameengine.model.datastructures.LinkedListNode;
import app.gameengine.model.gameobjects.Player;

/**
 * A {@code Game} subclass that organizes levels linearly, such that each level
 * has a single "next" level. This is implemented using the
 * {@link LinkedListNode} class.
 * <p>
 * This class implements the functionality to advance to the next level, as well
 * as additional functionality to replace or remove levels by name.
 *
 * @see LinkedListNode
 * @see Game
 * @see Level
 */
public class LinearGame extends Game {

    public LinearGame() {
        super();
    }

    public LinearGame(Player player) {
        super(player);
    }

    private LinkedListNode<Level> levelsHead;

    public LinkedListNode<Level> getLevelList(){
        return this.levelsHead;
    }

    public void setLevelList(LinkedListNode<Level> level){
        this.levelsHead = level;
    }

    public void addLevel(Level level) {
        if (this.levelsHead == null) {
            this.levelsHead = new LinkedListNode<>(level, null);
        } else {
            LinkedListNode<Level> current = this.levelsHead;
            while (current.getNext() != null) {
                current = current.getNext();
            }
            current.setNext(new LinkedListNode<>(level, null));
        }
    }

    @Override
    public void advanceLevel() {
        super.advanceLevel();
        Level currentLevel = this.getCurrentLevel();
        if (currentLevel == null || this.levelsHead == null) {
            return;
        }
        LinkedListNode<Level> head = this.levelsHead;
        while (head != null){
            if (head.getValue().getName().equals(currentLevel.getName())) {
                if (head.getNext() != null) {
                    this.loadLevel(head.getNext().getValue());
                }
                return;
            }
            head = head.getNext();
        }
    }

    public void removeLevelByName(String name) {
        if (this.levelsHead == null) {
            return;
        }

        if (this.levelsHead.getValue().getName().equals(name)) {
            this.levelsHead = this.levelsHead.getNext();
            return;
        }
        LinkedListNode<Level> current = this.levelsHead;
        while (current.getNext() != null) {
            if (current.getNext().getValue().getName().equals(name)) {
                current.setNext(current.getNext().getNext());
                return;
            }
            current = current.getNext();
        }
    }
}
