package app.gameengine.statistics;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import app.gameengine.model.datastructures.BinaryTreeNode;
import app.gameengine.model.datastructures.Comparator;
import app.gameengine.model.datastructures.LinkedListNode;

/**
 * A scoreboard for sorting scores of specific games using a BST.
 */
public class Scoreboard {

    private static String STATS_DIRECTORY = "data/stats/";
    private static String STATS_POSTFIX = "_stats.csv";

    private String statsPath;
    private Comparator<GameStat> comparator;
    private BinaryTreeNode<GameStat> root;
    private boolean isLoaded = false;

    public Scoreboard(String gameName, Comparator<GameStat> comparator) {
        this.statsPath = STATS_DIRECTORY + gameName.toLowerCase() + STATS_POSTFIX;
        this.comparator = comparator;
    }

    // --- Getters and Setters ---

    public Comparator<GameStat> getComparator() {
        return this.comparator;
    }

    public void setComparator(Comparator<GameStat> comparator) {
        this.comparator = comparator;
    }

    public BinaryTreeNode<GameStat> getScoreTree() {
        return this.root;
    }

    public void setScoreTree(BinaryTreeNode<GameStat> root) {
        this.root = root;
    }

    // --- Core Logic: addScore ---

    public void addScore(GameStat score) {
        if (this.root == null) {
            this.root = new BinaryTreeNode<>(score, null, null);
        } else {
            this.addScoreRecursive(this.root, score);
        }
    }

    private void addScoreRecursive(BinaryTreeNode<GameStat> currentNode, GameStat newScore) {
        // Use the comparator to decide direction: true -> left, false -> right
        if (this.comparator.compare(newScore, currentNode.getValue())) {
            if (currentNode.getLeft() == null) {
                currentNode.setLeft(new BinaryTreeNode<>(newScore, null, null));
            } else {
                addScoreRecursive(currentNode.getLeft(), newScore);
            }
        } else {
            if (currentNode.getRight() == null) {
                currentNode.setRight(new BinaryTreeNode<>(newScore, null, null));
            } else {
                addScoreRecursive(currentNode.getRight(), newScore);
            }
        }
    }

    // --- Core Logic: loadStats ---

    public void loadStats() {
        if (this.isLoaded) {
            return;
        }
        this.isLoaded = true;

        try {
            if (!Files.exists(Paths.get(this.statsPath))) {
                return;
            }

            try (BufferedReader reader = Files.newBufferedReader(Paths.get(this.statsPath))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length == 3) {
                        String name = parts[0];
                        double time = Double.parseDouble(parts[1]);
                        double score = Double.parseDouble(parts[2]);
                        this.addScore(new GameStat(name, time, score));
                    }
                }
            }
        } catch (IOException | NumberFormatException e) {
            System.err.println("Error loading stats: " + e.getMessage());
        }
    }

    // --- Core Logic: saveStats ---

    public void saveStats() {
        // Ensure stats are loaded before saving (prevents overwriting old stats if not loaded)
        this.loadStats();
        if (this.root == null) return;

        try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(this.statsPath))) {
            for (LinkedListNode<GameStat> stats = this.getScoreList(); stats != null; stats = stats.getNext()) {
                writer.write(stats.getValue().toString() + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // --- Core Logic: getScoreList (BST to LinkedList) ---

    public LinkedListNode<GameStat> getScoreList() {
        return getScoreList(this.root);
    }

    public LinkedListNode<GameStat> getScoreList(BinaryTreeNode<GameStat> node) {
        if (node == null) {
            return null;
        }

        // In-order traversal: Left -> Current -> Right

        // 1. Process left subtree
        LinkedListNode<GameStat> leftHead = getScoreList(node.getLeft());

        // 2. Process current node
        LinkedListNode<GameStat> currentMid = new LinkedListNode<>(node.getValue(), null);

        // 3. Process right subtree
        LinkedListNode<GameStat> rightHead = getScoreList(node.getRight());

        // 4. Assemble the sorted list
        if (leftHead == null) {
            currentMid.setNext(rightHead);
            return currentMid;
        } else {
            // Find the end of the left list to attach currentMid
            LinkedListNode<GameStat> tail = leftHead;
            while (tail.getNext() != null) {
                tail = tail.getNext();
            }
            tail.setNext(currentMid);
            currentMid.setNext(rightHead);
            return leftHead;
        }
    }
}