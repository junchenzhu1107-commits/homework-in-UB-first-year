package app.gameengine;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import app.display.common.Background;
import app.gameengine.model.gameobjects.DynamicGameObject;
import app.gameengine.model.gameobjects.StaticGameObject;
import app.games.commonobjects.*;
import app.games.mario.*;
import app.games.roguelikeobjects.DirectionalWall;
import app.games.roguelikeobjects.Marker;
import app.games.roguelikeobjects.RoguelikeLevel;
import app.games.topdownobjects.*;

public class LevelParser {

    public static Level parseLevel(Game game, String path) {
        String fullpath = "data/levels/" + path;
        try {
            List<String> allLines = Files.readAllLines(Paths.get(fullpath));
            if (allLines.isEmpty()) return null;

            String[] line1 = allLines.get(0).split(",");
            String levelType = line1[0];
            String name = line1[1];
            int width = Integer.parseInt(line1[2]);
            int height = Integer.parseInt(line1[3]);

            Level level;
            if (levelType.equals("MarioLevel")) {
                level = new MarioLevel(game, width, height, name);
            } else if (levelType.equals("RoguelikeLevel")) {
                level = new RoguelikeLevel(game, width, height, name);
            } else {
                level = new TopDownLevel(game, width, height, name);
            }

            String[] line2 = allLines.get(1).split(",");
            level.setPlayerStartLocation(Double.parseDouble(line2[1]), Double.parseDouble(line2[2]));

            String[] line3 = allLines.get(2).split(",");
            level.setBackground(readBackground(new ArrayList<>(Arrays.asList(line3))));

            for (int i = 3; i < allLines.size(); i++) {
                String[] parts = allLines.get(i).split(",");
                ArrayList<String> split = new ArrayList<>(Arrays.asList(parts));
                String category = parts[0];
                if (category.equals("StaticGameObject")) {
                    StaticGameObject sgo = readStaticObject(game, level, split);
                    if (sgo != null) level.getStaticObjects().add(sgo);
                } else if (category.equals("DynamicGameObject")) {
                    DynamicGameObject dgo = readDynamicObject(game, level, split);
                    if (dgo != null) level.getDynamicObjects().add(dgo);
                }
            }
            return level;
        } catch (Exception e) {
            return null;
        }
    }

    public static DynamicGameObject readDynamicObject(Game game, Level level, ArrayList<String> split) {
        String type = split.get(1);
        double x = Double.parseDouble(split.get(2));
        double y = Double.parseDouble(split.get(3));

        if (type.equals("Goomba")) {
            return new Goomba(x, y);
        } else if (type.equals("Koopa")) {
            return new Koopa(x, y);
        } else if (type.equals("Demon")) {
            return new Demon(x, y, Integer.parseInt(split.get(4)), Integer.parseInt(split.get(5)));
        } else if (type.equals("Tower")) {
            return new Tower(x, y);
        } else if (type.equals("Minotaur")) {
            return new Minotaur(x, y, Integer.parseInt(split.get(4)), Integer.parseInt(split.get(5)));
        } else if (type.equals("Archer")) {
            return new Archer(x, y, Integer.parseInt(split.get(4)), Integer.parseInt(split.get(5)));
        } else if (type.equals("Sorcerer")) {
            return new Sorcerer(x, y, Integer.parseInt(split.get(4)), Integer.parseInt(split.get(5)));
        }
        return null;
    }

    public static StaticGameObject readStaticObject(Game game, Level level, ArrayList<String> split) {
        String type = split.get(1);
        double x = Double.parseDouble(split.get(2));
        double y = Double.parseDouble(split.get(3));

        if (type.equals("Wall")) {
            return new Wall(x, y);
        } else if (type.equals("Goal")) {
            return new Goal(x, y, game);
        } else if (type.equals("InfoNode")) {
            return new InfoNode(x, y, split.get(4));
        } else if (type.equals("Block") || type.equals("Bricks") || type.equals("Ground")) {
            return new Block(x, y, type);
        } else if (type.equals("QuestionBlock")) {
            return new QuestionBlock(x, y);
        } else if (type.equals("HiddenBlock")) {
            return new HiddenBlock(x, y);
        } else if (type.equals("PipeEnd")) {
            return new PipeEnd(x, y);
        } else if (type.equals("PipeStem")) {
            return new PipeStem(x, y);
        } else if (type.equals("Flag")) {
            return new Flag(x, y, game);
        } else if (type.equals("AxePickup")) {
            return new AxePickup(x, y, game);
        } else if (type.equals("MagicPickup")) {
            return new MagicPickup(x, y, game);
        } else if (type.equals("PotionPickup")) {
            int heal = Integer.parseInt(split.get(4));
            return new PotionPickup(x, y, heal, game);
        } else if (type.equals("Spike")) {
            return new Spike(x, y);
        } else if (type.equals("Potion")) {
            int heal = Integer.parseInt(split.get(4));
            return new Potion(x, y, heal);
        } else if (type.equals("DirectionalWall")) {
            return new DirectionalWall(x, y, level);
        } else if (type.equals("Marker")) {
            String label = split.get(4);
            return new Marker(x, y, label);
        }

        return null;
    }

    public static Background readBackground(ArrayList<String> split) {
        if (split.get(0).equals("BackgroundImage")) {
            return new Background(new ArrayList<>(split.subList(1, split.size())));
        } else {
            return new Background(split.get(1), Integer.parseInt(split.get(2)), Integer.parseInt(split.get(3)));
        }
    }
}