package app.games.topdownobjects;

import app.gameengine.model.ai.DecisionTree;
import app.gameengine.model.ai.Decision;
import app.gameengine.model.ai.roguelike.MoveTowardPlayer;
import app.gameengine.model.datastructures.BinaryTreeNode; // 必须导入这个

public class Demon extends Enemy {

    public Demon(double x, double y, int maxHP, int strength) {
        super(x, y, maxHP, strength);
        this.spriteSheetFilename = "MiniWorldSprites/Characters/Monsters/Demons/ArmouredRedDemon.png";

        MoveTowardPlayer chase = new MoveTowardPlayer(this, "Chase");

        BinaryTreeNode<Decision> node = new BinaryTreeNode<>(chase, null, null);

        DecisionTree brain = new DecisionTree(node);

        this.setDecisionTree(brain);
    }

    public Demon(double x, double y) {
        this(x, y, 100, 30);
    }
}