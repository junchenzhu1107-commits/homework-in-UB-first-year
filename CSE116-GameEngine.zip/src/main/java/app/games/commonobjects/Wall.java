package app.games.commonobjects;

import app.display.common.SpriteLocation;
import app.gameengine.model.gameobjects.DynamicGameObject;
import app.gameengine.model.gameobjects.StaticGameObject;
import app.gameengine.model.physics.Hitbox;
import app.gameengine.model.physics.Vector2D;

/**
 * A {@code StaticGameObject} that prevents collision by moving any
 * {@code DynamicGameObject}s that collide with it.
 */
public class Wall extends StaticGameObject {

    public Wall(double x, double y) {
        super(x, y);
        this.spriteSheetFilename = "MiniWorldSprites/Ground/Cliff.png";
        this.defaultSpriteLocation = new SpriteLocation(3, 0);
    }

    @Override
    public void collideWithDynamicObject(DynamicGameObject otherObject) {
        Hitbox wallHitbox = this.getHitbox();
        Hitbox objectHitbox = otherObject.getHitbox();

        double x1 = wallHitbox.getLocation().getX();
        double y1 = wallHitbox.getLocation().getY();
        double w1 = wallHitbox.getDimensions().getX();
        double h1 = wallHitbox.getDimensions().getY();

        double x2 = objectHitbox.getLocation().getX();
        double y2 = objectHitbox.getLocation().getY();
        double w2 = objectHitbox.getDimensions().getX();
        double h2 = objectHitbox.getDimensions().getY();

        double overlapRight = (x1 + w1) - x2;
        double overlapLeft = (x2 + w2) - x1;
        double overlapBottom = (y1 + h1) - y2;
        double overlapTop = (y2 + h2) - y1;

        double minOverlap = overlapLeft;
        if (overlapRight < minOverlap){ minOverlap = overlapRight;}
        if (overlapTop < minOverlap){ minOverlap = overlapTop;}
        if (overlapBottom < minOverlap){ minOverlap = overlapBottom;}

        Vector2D pos = otherObject.getLocation();
        Vector2D vel = otherObject.getVelocity();

        if ( minOverlap == overlapRight){
            otherObject.setLocation(pos.getX() + overlapRight, pos.getY());
            otherObject.setVelocity(0, vel.getY());
        }else if( minOverlap == overlapLeft){
            otherObject.setLocation(pos.getX() - overlapLeft, pos.getY());
            otherObject.setVelocity(0, vel.getY());
        }else if( minOverlap == overlapBottom){
            otherObject.setLocation( pos.getX(), pos.getY() + overlapBottom);
            otherObject.setVelocity( vel.getX(), 0);
        }else if (minOverlap == overlapTop) {
            otherObject.setLocation(pos.getX(), pos.getY() - overlapTop);
            otherObject.setVelocity(vel.getX(), 0);
        }
    }
}
