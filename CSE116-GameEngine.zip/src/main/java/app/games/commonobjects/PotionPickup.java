package app.games.commonobjects;

import app.display.common.SpriteLocation;
import app.gameengine.Game;
import app.gameengine.Level;
import app.gameengine.model.gameobjects.Collectible;
import app.gameengine.model.gameobjects.Player;

public class PotionPickup extends Collectible {
    private int heal;

    public PotionPickup(double x, double y, int heal, Game game) {
        super(x, y, game, "Health Potion");
        this.heal = heal;
        this.spriteSheetFilename = "MiniWorldSprites/User Interface/Icons-Essentials.png";
        this.defaultSpriteLocation = new SpriteLocation(3, 1);
    }

    public int getHealAmount() { return this.heal; }

    @Override
    public void use(Level level) {
        Player player = level.getPlayer();
        player.setHP(player.getHP() + this.heal);
        player.removeActiveItem();
    }
}