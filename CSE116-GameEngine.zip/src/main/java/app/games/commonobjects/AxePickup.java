package app.games.commonobjects; // 同一个包，不需要 import 投射物

import app.gameengine.Game;
import app.gameengine.Level;
import app.display.common.SpriteLocation;
import app.gameengine.model.gameobjects.Collectible;
import app.gameengine.utils.Timer;

public class AxePickup extends Collectible {
    private Timer timer;

    public AxePickup(double x, double y, Game game) {
        super(x, y, game, "Axe");
        this.spriteSheetFilename = "MiniWorldSprites/Objects/Axe.png";
        this.defaultSpriteLocation = new SpriteLocation(0, 0);
        this.timer = new Timer(0.25);
    }

    public Timer getTimer() { return this.timer; }

    @Override
    public void use(Level level) {
        if (this.timer.check() > 0) {
            // 这里直接 new 同包下的类
            level.getPlayer().fireProjectile(new PlayerAxeProjectile(0, 0), 5, level);
        }
    }

    @Override
    public void update(double dt, Level level) {
        super.update(dt, level);
        this.timer.advance(dt);
    }
}