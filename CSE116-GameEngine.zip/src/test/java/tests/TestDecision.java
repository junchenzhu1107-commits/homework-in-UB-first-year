package tests;

import app.gameengine.Level;
import app.gameengine.model.ai.Decision;
import app.gameengine.model.gameobjects.Agent;

public class TestDecision extends Decision {
    private boolean result;
    private boolean used = false;

    public TestDecision(Agent agent, String name, boolean result) {
        super(agent, name);
        this.result = result;
    }

    public boolean isUsed() {
        return this.used;
    }

    @Override
    public boolean decide(double dt, Level level) {
        return this.result;
    }

    @Override
    public void doAction(double dt, Level level) {
        this.used = true;
    }
}