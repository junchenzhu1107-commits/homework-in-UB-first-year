package tests;

import app.gameengine.model.datastructures.LinkedListNode;
import app.gameengine.model.physics.Vector2D;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class TestUtils {

    public static void validatePath(LinkedListNode<Vector2D> path) {
        if (path == null) {
            return;
        }

        LinkedListNode<Vector2D> current = path;
        while (current != null) {
            Vector2D p1 = current.getValue();

            assertTrue("Path coordinates must be whole numbers", p1.getX() == Math.floor(p1.getX()));
            assertTrue("Path coordinates must be whole numbers", p1.getY() == Math.floor(p1.getY()));

            LinkedListNode<Vector2D> nextNode = current.getNext();
            if (nextNode != null) {
                Vector2D p2 = nextNode.getValue();

                double distance = Vector2D.euclideanDistance(p1, p2);
                assertEquals("Nodes in path must be exactly 1 tile apart", 1.0, distance, 1e-5);

                assertTrue("Movement must be strictly horizontal or vertical",
                        (Math.abs(p1.getX() - p2.getX()) == 1 && p1.getY() == p2.getY()) ||
                                (Math.abs(p1.getY() - p2.getY()) == 1 && p1.getX() == p2.getX())
                );
            }

            current = nextNode;
        }
    }
}