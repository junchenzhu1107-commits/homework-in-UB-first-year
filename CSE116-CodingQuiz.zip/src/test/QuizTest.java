package test;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.HashMap;

import org.junit.Test;

import quiz.*;

public class QuizTest {

    // OPTIONAL. You may write any test cases you want here, but they will not be graded in any way.


    

}
