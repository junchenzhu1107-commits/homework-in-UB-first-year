package quiz;

import java.util.ArrayList;
import java.util.HashMap;

public class Quiz0 {
    public static int shortestStringIndex(ArrayList<String> lst) {
        if (lst.isEmpty()) {
            return -1;
        }
        int shortestIndex = 0;
        for (int i = 0; i < lst.size(); i++) {
            if (lst.get(i).length() < lst.get(shortestIndex).length()) {
                shortestIndex = i;
            }
        }
        return shortestIndex;
    }

    public static int isPerfectSquare(int num) {
        for (int i = 1; i * i <=num; i++) {
            if (i * i == num) {
                return i;
            }
        }
        return 0;
    }

    public static boolean isFactor(int num1, int num2) {
        if (num1 % num2 == 0) {
            return true;
        }
        return false;
    }

    public static boolean valueContainsString(HashMap<String, String> map, String str) {
        ArrayList<String> lst = new ArrayList<>();
        for (String item :map.values()){
            lst.add(item);
        }
        for (int i=0; i<lst.size(); i++){
            if (lst.get(i)==str){
                return true;
            }
        }
        return false;
    }

    // TODO: Write your methods here. Every method for this quiz is public and static
    // Good luck!

}
